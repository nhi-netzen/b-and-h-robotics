# MENU-UEH > 2025-05-16 6:47pm
https://universe.roboflow.com/nhii/menu-ueh

Provided by a Roboflow user
License: CC BY 4.0

